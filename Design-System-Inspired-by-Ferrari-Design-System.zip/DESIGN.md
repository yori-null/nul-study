---
name: "Design System Inspired by Ferrari"
category: Brands
surface: web
colors:
  hover-bg: "#1eaedb"
  the-vast-majority-of-the-interface-lives-in-black-white-and-a-carefully-calibrated-gray-scale-from: "#303030"
  ferrari-red: "#da291c"
  the-vast-majority-of-the-interface-lives-in-black-white-and-a-carefully-calibrated-gray-scale-from-303030-dark-surfaces-through: "#8f8f8f"
  the-vast-majority-of-the-interface-lives-in-black-white-and-a-carefully-calibrated-gray-scale-from-303030-dark-surfaces-through-8f8f8f-mid-tones-to: "#d2d2d2"
  two-yellows-racing-yellow: "#fff200"
  success-green: "#03904a"
---

# Design System Inspired by Ferrari

> Category: Brands

> Surface: web

*> Category: Automotive > Luxury automotive.*

null

## Color Palette

| Role | Name | Hex | Usage |
| --- | --- | --- | --- |
| background | Hover: bg | `#1eaedb` | page canvas |
| foreground | The vast majority of the interface lives in black, white, and a carefully calibrated gray scale  from | `#303030` | body text and headings |
| accent | Ferrari Red | `#da291c` | primary actions and emphasis |
| surface | The vast majority of the interface lives in black, white, and a carefully calibrated gray scale  from  #303030  dark surfaces through | `#8f8f8f` | cards and panels |
| muted | The vast majority of the interface lives in black, white, and a carefully calibrated gray scale  from  #303030  dark surfaces through  #8F8F8F  mid tones to | `#d2d2d2` | secondary text and metadata |
| border | Two yellows — Racing Yellow | `#fff200` | rules and dividers |
| accent-secondary | Success Green | `#03904a` | secondary actions and links |

## Typography
- **Display:** FerrariSans — weights 400, 700 — fallbacks: system-ui, -apple-system, Segoe UI, Helvetica Neue, Arial, sans-serif
- **Body:** FerrariSans — weights 400, 700 — fallbacks: system-ui, -apple-system, Segoe UI, Helvetica Neue, Arial, sans-serif

## Voice & Tone

- **Adjectives:** (none yet)
- **Tone:** null

### Messaging pillars
- null
- > Category: Automotive > Luxury automotive. Chiaroscuro editorial, Ferrari Red accents, cinematic black.

### Vocabulary
- **Use:** (none yet)
- **Avoid:** (none yet)

## Imagery

- **Style:** (none yet)
- **Subjects:** (none yet)
- **Treatment:** (none yet)
- **Avoid:** (none yet)

## Layout

- **Radius:** 8px
- **Border weight:** 1px
- **Spacing:** 8px baseline grid

### Posture rules
- (none)
