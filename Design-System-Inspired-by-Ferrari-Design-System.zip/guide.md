# Design System Inspired by Ferrari — Brand Guide

*> Category: Automotive > Luxury automotive.*

null

Extracted from designmd://design-system-inspired-by-ferrari.

## Color roles

- **Hover: bg** (`#1eaedb`) — background: page canvas
- **The vast majority of the interface lives in black, white, and a carefully calibrated gray scale  from** (`#303030`) — foreground: body text and headings
- **Ferrari Red** (`#da291c`) — accent: primary actions and emphasis
- **The vast majority of the interface lives in black, white, and a carefully calibrated gray scale  from  #303030  dark surfaces through** (`#8f8f8f`) — surface: cards and panels
- **The vast majority of the interface lives in black, white, and a carefully calibrated gray scale  from  #303030  dark surfaces through  #8F8F8F  mid tones to** (`#d2d2d2`) — muted: secondary text and metadata
- **Two yellows — Racing Yellow** (`#fff200`) — border: rules and dividers
- **Success Green** (`#03904a`) — accent-secondary: secondary actions and links

## Typography

- Display: FerrariSans
- Body: FerrariSans

## Messaging pillars

- null
- > Category: Automotive > Luxury automotive. Chiaroscuro editorial, Ferrari Red accents, cinematic black.
